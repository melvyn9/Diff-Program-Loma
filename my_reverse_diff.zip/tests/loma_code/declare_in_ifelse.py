def declare_in_ifelse(x : In[float]) -> float:
    if x > 0.0:
        y : Array[float, 10]
    return x
