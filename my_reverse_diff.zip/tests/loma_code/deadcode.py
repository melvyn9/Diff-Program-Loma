def deadcode(x : In[int]) -> int:
    return x
    y : int = x