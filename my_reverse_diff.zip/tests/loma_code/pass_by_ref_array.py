def pass_by_ref_array(arr_in : In[Array[int]], arr_out : Out[Array[int]]):
    arr_out[3] = arr_in[5] * 3
    