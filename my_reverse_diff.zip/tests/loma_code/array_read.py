def array_read(x : In[Array[float]]) -> float:
    return x[0]
