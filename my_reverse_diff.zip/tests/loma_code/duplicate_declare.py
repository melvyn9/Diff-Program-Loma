def duplicate_declare() -> float:
    x : float = 5
    x : float = 6
    return 0
