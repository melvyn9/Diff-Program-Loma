def binary_ops() -> float:
    x : float = 5.0
    y : float = 6.0
    a : float = x + y
    b : float = a - x
    c : float = b * y
    d : float = c / a
    return d