def mutation() -> float:
    a : float = 5.0
    a = 6.0
    return a
