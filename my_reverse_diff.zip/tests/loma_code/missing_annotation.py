def missing_annotation(x : float) -> float:
    return x
