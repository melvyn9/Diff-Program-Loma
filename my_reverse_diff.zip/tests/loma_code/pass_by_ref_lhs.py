def pass_by_ref_lhs(x : Out[int]):
    x = 5
    