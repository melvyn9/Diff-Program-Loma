def early_return(x : In[int]) -> float:
    if x > 0:
        return 0.0
    return 1.0
