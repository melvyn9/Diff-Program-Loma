def foo(x : In[int], y : In[int]) -> int:
    return x + y

def func_decl() -> float:
    return foo(42, 0)
