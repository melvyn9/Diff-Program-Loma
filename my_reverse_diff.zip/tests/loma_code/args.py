def args(x : In[float], y : In[int]) -> int:
    z : int = x
    return z + y
