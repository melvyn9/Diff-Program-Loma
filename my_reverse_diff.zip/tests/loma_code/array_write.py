def array_write(x : Out[Array[float]]):
    x[0] = 2.0
