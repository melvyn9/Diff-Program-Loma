def intrinsic_func_call() -> float:
    return sin(3.0)
