def while_loop() -> int:
    i : int = 0
    s : int = 0
    while (i < 10, max_iter := 10):
        s = s + i
        i = i + 1
    return s
