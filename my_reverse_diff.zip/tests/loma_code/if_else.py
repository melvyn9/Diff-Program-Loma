def if_else(x : In[float]) -> float:
    z : float = 0.0
    if x > 0:
        z = 4.0
    else:
        z = -4.0
    return z
