def declaration_int() -> int:
    x : int = 4
    return x
