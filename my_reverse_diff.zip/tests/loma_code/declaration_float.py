def declaration_float() -> float:
    x : float = 5
    return x
