def declare_unbounded_array(x : In[float]) -> float:
    y : Array[float]
    return x
