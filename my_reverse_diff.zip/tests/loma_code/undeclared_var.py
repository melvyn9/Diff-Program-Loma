def undeclared_var() -> float:
    a : float = 5.0
    b = 6.0
    return a
