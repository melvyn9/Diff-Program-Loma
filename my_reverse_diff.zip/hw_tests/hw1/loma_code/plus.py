def plus(x : In[float], y : In[float]) -> float:
    return x + y

d_plus = fwd_diff(plus)
