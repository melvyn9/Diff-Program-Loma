def subtract(x : In[float], y : In[float]) -> float:
    return x - y

d_subtract = rev_diff(subtract)
