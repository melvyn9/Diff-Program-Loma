def square(x : In[float]) -> float:
    return x * x

d_square = rev_diff(square)
