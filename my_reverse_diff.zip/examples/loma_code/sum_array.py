def sum_array(arr : In[Array[float]], arr_size : In[int]) -> float:
    i : int = 0
    s : float = 0.0
    while (i < arr_size, max_iter := 1000):
        s = s + arr[i]
        i = i + 1
    s_relu : float = 0.0
    if s > 0:
    	s_relu = s
    return s_relu
