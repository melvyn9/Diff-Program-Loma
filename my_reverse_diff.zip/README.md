# loma

This is an educational compiler/programming language for differentiable programming, used for the course [CSE 291](https://cseweb.ucsd.edu/~tzli/cse291/) in UCSD.

See [this PDF](https://cseweb.ucsd.edu/~tzli/cse291/sp2024/homework0.pdf) for a quick introduction to the language and compiler.